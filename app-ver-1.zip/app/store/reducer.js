import { combineReducers } from 'redux'

import session from './session'
import chat from './chat'
import channel from './channel'
import user from './user';

export default combineReducers({
  session,
  chat,
  channel,
  user
})
