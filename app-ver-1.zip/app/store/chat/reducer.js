import * as types from './actionTypes'

const initialState = {
  sending: false,
  sendingError: null,
  message: '',
  conversation: {},
  loadMessagesError: null,
  loaded: false
}

const chat = (state = initialState, action) => {
  // console.log('action', action)
  switch(action.type) {
    case types.CHAT_MESSAGE_LOADING:
      return { ...state, sending: true, sendingError: null }
    case types.CHAT_MESSAGE_ERROR:
      return { ...state, sending: false, sendingError: action.error }
    case types.CHAT_MESSAGE_SUCCESS:
      return { ...state, message: '', sending: false, sendingError: null }
    case types.CHAT_MESSAGE_UPDATE:
      return { ...state, message: action.text }
    case types.CHAT_LOAD_MESSAGES_SUCCESS:
      return { ...state, loaded: true, conversation: action.conversation }
    case types.CHAT_LOAD_MESSAGES_ERROR:
      return { ...state, loaded: true, loadMessagesError: action.error }
    case types.CHAT_START_TYPING:
      return { ...state, loaded: true, loadMessagesError: action.error }
    case types.CHAT_FINISH_TYPING:
      return { ...state, loadMessagesError: action.error }
      case types.CHAT_LOADING_MESSAGES:
      return { ...state, loaded: false }
    default:
      return state
  }
}

export default chat
