import * as types from './actionTypes'
import * as API from '../../configs/api'
import firebaseService from '../../services/firebase'
import * as MyFireBase from '../../services/MyFireBase'

const FIREBASE_DATABASE = firebaseService.database()
const FIREBASE_REF_MESSAGES = firebaseService.database().ref('Messages')
const FIREBASE_REF_MESSAGES_LIMIT = 20

export const sendMessage = (conversation, currentUser, message) => {
  return (dispatch) => {
    dispatch(chatMessageLoading())
    // console.log('sendMessage', conversation, 'currentUser', currentUser, 'message', message);
    const data = {
      parentId: conversation.id,
      userId: currentUser.id,
      type: 1,
      userName: currentUser.name,
      content: message,
      imageURL: "",
      status: 0,
    };

    var params = Object.keys(data).map(function(k) {
      return encodeURIComponent(k) + '=' + encodeURIComponent(data[k])
    }).join('&');

    const url = API.URL_SET_DISCUSSION + '?' + params;
    // console.log('insert discussion, params', params, 'data', data, 'string json', JSON.stringify(data), '\nurl', url)
    fetch(url)
    .then((response) => response.json())
    .then(function(json){
      MyFireBase.sendDataChat(conversation.id + '', json, 1, function(data){
        console.log('sendDataChat', data)
      })
      dispatch(chatMessageSuccess(conversation))
    }).catch(function(error){
      dispatch(chatMessageError())
    })
  }
}

export const updateMessage = text => {
  return (dispatch) => {
    // TODO: add status typing to firebase => typing function
    dispatch(chatUpdateMessage(text))
  }
}

export const loadMessages = (userId, friendId) => {
  return (dispatch) => {
    const url = 'https://deploy-temp.appspot.com/get-conversation?userId='+userId+'&friendId='+friendId;
    dispatch(messageLoading())
    fetch(url)
    .then((response) => response.json())
    .then(function(json){
      dispatch(loadMessagesSuccess(json))
    })
    .catch(function(error){
      dispatch(loadMessagesError(error.message))
    })
  }
}

export const typingMessage = (isTyping) => {
  return (dispatch) => {
    dispatch(chatStartTyping())
    FIREBASE_REF_MESSAGES.limitToLast(FIREBASE_REF_MESSAGES_LIMIT).on('value', (snapshot) => {
      dispatch(chatFinishTyping(snapshot.val()))
    }, (errorObject) => {
      console.log('typingMessage error', errorObject);
    })
  }
}

const chatStartTyping = () => ({
  type: types.CHAT_START_TYPING
})

const chatFinishTyping = () => ({
  type: types.CHAT_FINISH_TYPING
})

const chatMessageLoading = () => ({
  type: types.CHAT_MESSAGE_LOADING
})

const chatMessageSuccess = () => ({
  type: types.CHAT_MESSAGE_SUCCESS
})

const chatMessageError = error => ({
  type: types.CHAT_MESSAGE_ERROR,
  error
})

const chatUpdateMessage = text => ({
  type: types.CHAT_MESSAGE_UPDATE,
  text
})

const loadMessagesSuccess = (conversation) => ({
  type: types.CHAT_LOAD_MESSAGES_SUCCESS,
  conversation
})

const messageLoading = () => ({
  type: types.CHAT_LOADING_MESSAGES
})

const loadMessagesError = error => ({
  type: types.CHAT_LOAD_MESSAGES_ERROR,
  error
})
