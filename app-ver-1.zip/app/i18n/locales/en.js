export default {
  login: 'Login',
  signup: 'Sign Up',

  account: 'Account',
  password: 'Password',

  chat: 'Chat',
  message: 'Message',

  error: 'Error',

  you: 'You',

  placeholder: 'There are no messages yet',
}
