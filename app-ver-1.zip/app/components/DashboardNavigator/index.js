import { StackNavigator } from 'react-navigation'

import ChannelScreen from './ChannelScreen'
import ChatScreen from './ChatScreen'
import UserScreen from './UserScreen'

const routeConfig = {
  User: { screen: UserScreen },
  Channel: { screen: ChannelScreen },
  Chat: { screen: ChatScreen },
}

export default StackNavigator(routeConfig)
