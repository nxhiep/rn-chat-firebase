import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'

import { getUsers } from '../../../../store/user/actions'
import { AsyncStorage} from 'react-native'

import { View, Text } from 'react-native'

import UserListComponent from './Component'
import LoadingIndicator from '../../../AuthScreen/LoadingIndicator'

class UserListContainer extends Component {

  constructor(){
    super();
    this.state = {
      currentUser: null
    }
    // AsyncStorage.getItem("user").then((user) => {
    //   console.log('getCurrent user from storage', user)
    //   this.setState({currentUser : JSON.parse(user)});
    // }).done();
    AsyncStorage.getItem("user").then((user) => {
      console.log('getCurrent user from storage 222', user)
      this.setState({currentUser : JSON.parse(user)});
    }).done();
  }

  componentDidMount() {
    this.props.getUsers();
  }

  render() {
    console.log('this.state.currentUser', this.state.currentUser)
    if(!!this.state.currentUser){
      const users = !! this.props.users ? this.props.users : [];
      const data = users.filter((a) => {
        return a.id != this.state.currentUser.id
      })
      // console.log('UserListContainer', data, this.state.currentUser);
      return (
        <UserListComponent
          data={data} {...this.props} />
      )
    } else {
      return <View><Text>Loading...</Text></View>
    }
  }
}

const mapStateToProps = state => ({
  users: state.user.users,
  error: state.user.errorUsers
})

const mapDispatchToProps = (dispatch) => {
  return {
    getUsers: () => {
      dispatch(getUsers())
    }
  }
}

UserListContainer.propTypes = {
  users: PropTypes.array,
  error: PropTypes.string,
  getUsers: PropTypes.func.isRequired,
}

export default connect(mapStateToProps, mapDispatchToProps)(UserListContainer)
