import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import ChatScreen from './Component'
import LogoutButton from './LogoutButton'
import translations from '../../../i18n'
import { loadMessages } from '../../../store/chat/actions'
import { View, Text } from 'react-native'
import { AsyncStorage} from 'react-native'

class ChatScreenContainer extends Component {

  constructor(){
    super();
    this.state = {
      currentUser: null
    }
  }

  static navigationOptions = {
    title: translations.t('chat'),
    headerRight: <LogoutButton />
  }

  componentDidMount() {
    const friend = this.props.navigation.state.params.friend;
    console.log('ChatScreenContainer', this.props);
    AsyncStorage.getItem("user").then((user) => {
      // console.log('getCurrent user from storage 222', user)
      this.setState({currentUser : JSON.parse(user)});
      this.props.loadMessages(this.state.currentUser.id, friend.id)
    }).done();
  }

  render() {
    // console.log('ChatScreen', this.props)
    if(this.state.currentUser == null){
      return <View><Text>Loading...</Text></View>
    }
    return (
      <ChatScreen {...this.props.chat} currentUser={this.state.currentUser} />
    )
  }
}

const mapStateToProps = state => ({
  ...state,
})

const mapDispatchToProps = (dispatch) => {
  return {
    loadMessages: (currentUserId, friendId) => {
      dispatch(loadMessages(currentUserId, friendId))
    }
  }
}

ChatScreenContainer.propTypes = {
  error: PropTypes.string,
  loadMessages: PropTypes.func.isRequired
}


export default connect(mapStateToProps, mapDispatchToProps)(ChatScreenContainer)
