import React, { Component } from 'react'
import { connect } from 'react-redux'
import PropTypes from 'prop-types'

import { sendMessage, updateMessage, loadMessages } from '../../../../store/chat'

import MessageForm from './Component'


class MessageFormContainer extends Component {

  constructor(props){
    super(props)
  }

  render() {
    // console.log('this.props.conversation', this.props.conversation)
    // console.log('MessageFormContainer', this.props, 'this.props.chat', this.props.chat, 'conversation', this.props.conversation, this.props.currentUser)
    return (
      <MessageForm
        {...this.props.chat}
        currentUser={this.props.currentUser}
        conversation={this.props.conversation}
        sendMessage={this.props.sendMessage}
        loadMessages={this.props.loadMessages}
        updateMessage={this.props.updateMessage} />
    )
  }
}

const mapStateToProps = state => ({
  ...state,
})

const mapDispatchToProps = dispatch => {
  return {
    sendMessage: (conversation, currentUser, message) => {
      dispatch(sendMessage(conversation, currentUser, message))
    }, 
    updateMessage: (text) => {
      dispatch(updateMessage(text))
    },
    loadMessages: (currentUserId, friendId) => {
      dispatch(loadMessages(currentUserId, friendId))
    }
  }
}

MessageFormContainer.propTypes = {
  sending: PropTypes.bool.isRequired,
  sendMessage: PropTypes.func.isRequired,
  updateMessage: PropTypes.func.isRequired,
  message: PropTypes.string.isRequired,
  sendingError: PropTypes.string
}

export default connect(mapStateToProps, mapDispatchToProps)(MessageFormContainer)
