import React, { Component } from 'react'
import { FlatList, Text } from 'react-native'
import PropTypes from 'prop-types'

import firebaseService from '../../../../services/firebase'

import MessageRow from './MessageRow'

import translations from '../../../../i18n'

import styles from './Styles'

const ITEM_HEIGHT = 50

class MessageListComponent extends Component {

  constructor() {
    super()

    this.state = {
      firstLoaded: false,
      refresh: false
    }

    this.renderItem = (item) => {
      return <MessageRow 
        {...this.props}
        message={item.item}/>
    }

    this.emptyList = () => {
      return (
        <Text
          style={styles.placeholder}>
          {translations.t('placeholder')}
        </Text>
      )
    }

    this.itemLayout = (data, index) => (
      {length: ITEM_HEIGHT, offset: ITEM_HEIGHT * index, index}
    )
  }

  componentDidMount() {
    firebaseService.database().ref(this.props.conversation.id + '').on("value", 
      (dataJson) => {
        if(!this.state.firstLoaded){
          this.setState({ firstLoaded: true })
          return;
        }
        console.log('on value dataJson', dataJson.val())
        this.props.conversation.discussions.push(dataJson.val().updated.data);
        this.setState({refresh: true})
      },
      function (err) {
      }
    );
  }

  componentDidUpdate() {
    if (this.props.conversation.discussions.length) {
        this.flatList.scrollToIndex({animated: true, index: 0});
    }
  }

  render() {
    // console.log('MessageListComponent render', this.props)
    const conversation = this.props.conversation
    // console.log('conversation', conversation, 'discussions', conversation.discussions);
    const discussions = !!conversation.discussions ? conversation.discussions.sort(function(a, b){
      return b.createDate - a.createDate;
    }) : [];
    // console.log('conversation.discussions', conversation.discussions, discussions);
    const contentContainerStyle = discussions.length ? null : styles.flatlistContainerStyle
    return (
      <FlatList
        ref={(c) => { this.flatList = c }}
        style={styles.container}
        contentContainerStyle={contentContainerStyle}
        data={discussions}
        extraData={this.state.refresh}
        onPress={() => { this.setState({ refresh: !refresh}) }}
        keyExtractor={item => item.id}
        renderItem={this.renderItem}
        getItemLayout={this.itemLayout}
        ListEmptyComponent={this.emptyList}
        inverted />
    )
  }
}

MessageListComponent.propTypes = {
  conversation: PropTypes.shape({
    discussions: PropTypes.array
  })
}

export default MessageListComponent
