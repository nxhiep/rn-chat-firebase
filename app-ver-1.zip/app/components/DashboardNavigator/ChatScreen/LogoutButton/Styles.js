import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  container: {
    flex: 1,
    marginRight: 10,
    height: 40,
    alignItems: 'center',
    justifyContent:'center'
  }
})
