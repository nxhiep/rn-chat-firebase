export const firebaseConfig = {
  apiKey: "AIzaSyBT8DmFSfHd3vYK8lFVnpRUkkABczLyFbU",
  authDomain: "chat-rn-firebase.firebaseapp.com",
  databaseURL: "https://chat-rn-firebase.firebaseio.com",
  projectId: "chat-rn-firebase",
  storageBucket: "chat-rn-firebase.appspot.com",
  messagingSenderId: "769105108409"
}