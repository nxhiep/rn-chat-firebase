export const URL_GET_USERS = 'https://deploy-temp.appspot.com/get-users'
export const URL_SET_DISCUSSION = 'https://deploy-temp.appspot.com/set-discussion'
export const URL_GET_CHANNEL = 'https://deploy-temp.appspot.com/get-channels'
export const URL_LOGIN = 'https://deploy-temp.appspot.com/login'